import javafx.scene.*
import javafx.scene.text.*
import javafx.scene.paint.*
import javafx.stage.*
println '# usage:'
println '#   dc = new clock.DigitalClock()'
println '#   dc.start()'
println '#   dc.setTimeZone("GMT")'
println '#   dc.setFontSize(100)'